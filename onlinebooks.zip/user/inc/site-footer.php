    <div class="container">
            <div class="row footer-top">
                <div class="col-lg-3 footer-grid-w3ls">
                    <div class="footer-title">
                        <h3>About Us</h3>
                    </div>
                    <div class="footer-text">
                        <p>Please remember though that how far you go is up to you. There is no substitute for your own work and effort in succeeding in this business.</p>
                       <!--
                        <div class="social-icon footer text-left mt-4">
                            <div class="icon-social">
                                <a href="#" class="button-footr">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="button-footr">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="#" class="button-footr">
                                    <i class="fab fa-dribbble"></i>
                                </a>

                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="col-lg-3 footer-grid-w3ls">
                    <div class="footer-title">
                        <h3>Get in touch</h3>
                    </div>
                    <div class="contact-info">
                       
                        <div class="phone">
                            <h4>Contact :</h4>
                         
                            <p>Email :
                                <a href="mailto:info@dhanyog.in">info@dhanyog.in</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 footer-grid-w3ls">
                    <div class="footer-title">
                        <h3>Useful Links</h3>
                    </div>
                    <ul class="links">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <a href="about.php">About</a>
                        </li>
                        <li>
                            <a href="business-plan.php">Business Plan</a>
                        </li>
                        <li>
                            <a href="product.php">Products</a>
                        </li>
                        <li>
                            <a href="contact.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-3 footer-grid-w3ls">
                    <div class="footer-title">
                        <h3>Open Hours</h3>
                    </div>
                    <div class="footer-text">
                        <p>We work 6 days a week, Please contact us for any inquiry:
                        Monday - Friday: 10 am - 6 pm <br>
                        Saturday: 10 am - 6 pm</p>
                        
                    </div>
                </div>
            </div>
            <div class="copyright mt-4">
                <p class="copy-right text-center ">&copy; 2020. All Rights Reserved | Design by
                    <a href="https://dhanyog.in/">dhanyog.in </a>
                </p>
            </div>
        </div>