<?php

$companyName="TOB";
echo $companyName;
?>