

        <div class="topbar-section">
            <div class="container-fluid">
                 <div class="row ">
                    <div class="col-md-5">
                        <div class="logo">
                            <a href="index.php"><img src="images/logo.jpg"  class="float-left img-fluid" alt=""></a>
                        </div><!-- end logo -->
                         </div><!-- end header-logo -->
                    
                
                
                    <div class="col-md-7">

                        <div class="topsocial float-right">
                    <a href="index.php"  data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
                    <a href="index.php" data-toggle="tooltip" data-placement="bottom" title="Youtube"><i class="fa fa-youtube"></i></a>
                    <a href="index.php"  data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
                    <a href="index.php"  data-toggle="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram"></i></a>
                    <div>
                        <i class="fa fa-envelope"><b> info@theonlinebooks.in</b></i>
                    </div>
                        </div><!-- end social -->


                    </div><!-- end col -->

                    </div>
                 <!--   <div class="col-lg-4 hidden-md-down">
                        <div class="topmenu text-center">
                            <ul class="list-inline">
                <li class="list-inline-item"><a href="blog-category-02.html"><i class="fa fa-bolt"></i> Hot Topics</a></li>
                <li class="list-inline-item"><a href="page-contact.html"><i class="fa fa-user-circle-o"></i> Write for us</a></li>
                            </ul> end ul -->
                        </div><!-- end topmenu -->
                    </div><!-- end col -->

                   
               