<div class="col-lg-3">
                         <?php 
                        include("inc/recent_articles.php");
                        ?>

                </div><!-- end row -->

<hr class="invis">