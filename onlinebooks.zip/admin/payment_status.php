<?php 
include ("inc/connect.php");
$pay_id=$_GET['payid'];
$sts=$_GET['sts'];
$sql="update payment set pay_status='$sts' where pay_id='$pay_id'";
mysqli_query($conn,$sql);
header("Location:manage_payment.php");
?>